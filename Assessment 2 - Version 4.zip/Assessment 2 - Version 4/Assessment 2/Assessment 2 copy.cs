using System;
using System.Windows.Forms;

namespace Assessment_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static int max = 24;
        int[] Astronomical_Processing = new int[max];
        int nextEmptySpot = 0;

        private void DisplayTasks()
        {
            ListBox.Items.Clear();
            for (int x = 0; x < nextEmptySpot; x++)
            {
                ListBox.Items.Add(Astronomical_Processing[x]);
            }
        }

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                Astronomical_Processing[nextEmptySpot] = int.Parse(TextBox.Text);
                nextEmptySpot++;
                DisplayTasks();
                TextBox.Clear();
            }
            else
                ToolStripStatus.Text = "Cannot Add: Text box is empty";
        }

        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                string currentItem = ListBox.SelectedItem.ToString();
                int taskIndex = ListBox.FindString(currentItem);
                Astronomical_Processing[taskIndex] = int.Parse(TextBox.Text);
            }
            else
            {
                ToolStripStatus.Text = "Cannot Edit: Please select an item from the list";
            }
            DisplayTasks();
            TextBox.Clear();
        }

        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            if (ListBox.SelectedIndex != -1)
            {
                string currentItem = ListBox.SelectedItem.ToString();
                int taskIndex = ListBox.FindString(currentItem);
                DialogResult DeleteTask = MessageBox.Show("Are you sure you want to Delete this task?", "Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (DeleteTask == DialogResult.Yes)
                {
                    Astronomical_Processing[taskIndex] = Astronomical_Processing[nextEmptySpot - 1];
                    nextEmptySpot--;
                    ToolStripStatus.Text = "Task has been Deleted";
                    DisplayTasks();
                    TextBox.Clear();
                }
                else
                    ToolStripStatus.Text = "Task NOT Deleted";
            }
            else
                ToolStripStatus.Text = "Cannot Delete: Please select a task from the list";
        }

        private void ButtonSort_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < nextEmptySpot; i++)
            {
                for (int j = i + 1; j < nextEmptySpot; j++)
                {
                    if (Astronomical_Processing[i] > Astronomical_Processing[j])
                    {
                        int temp = Astronomical_Processing[i];
                        Astronomical_Processing[i] = Astronomical_Processing[j];
                        Astronomical_Processing[j] = temp;
                    }
                }
            }
            DisplayTasks();
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {

            //if(!string.IsNullOrEmpty(TextBoxTask.Text))
            //{
            int target = int.Parse(TextBox.Text);
            int min = 0;
            int max = nextEmptySpot - 1;
            int mid = 0;
            bool found = false;

            while (min <= max)
            {

                mid = (min + max) / 2;
                if (target == Astronomical_Processing[mid])
                {
                    found = true;
                    break;
                }
                else if (target < Astronomical_Processing[mid])
                {
                    max = mid - 1;
                }
                else
                {
                    min = mid + 1;
                }
            }
            if (found)
                MessageBox.Show("Found at element [" + mid + "]");
            //ListBoxDisplayAllTasks.SelectedIndex = mid;

            else
                MessageBox.Show("Not Found");
            //toolStripStatusLabel1.Text = "Not Found";
            //}
            //else
            //toolStripStatusLabel1.Text = "Search failed. Please enter text into text box";
        }

        private void ButtonTest_Click(object sender, EventArgs e)
        {
            Random randNum = new Random();
            for (int i = 0; i < 24; i++)
            {
                Astronomical_Processing[nextEmptySpot] = randNum.Next(10, 100);
                nextEmptySpot++;
            }
            DisplayTasks();
        }

    }

}
