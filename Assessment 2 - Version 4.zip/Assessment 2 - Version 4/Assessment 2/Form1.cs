﻿using System;
using System.Windows.Forms;
//Alexis and Jesse
//Assessment 2 - Sprint 1
//Version 4
//21/09/2021
//Astronomical Processing program
//Program that records hourly neutrino interactions input by the user
namespace Assessment_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static int max = 24;
        //New array of integers called Astronomical_Processing with max of 24 items
        int[] Astronomical_Processing = new int[max];
        int nextEmptySpot = 0;


        //Displays the items in the array in the listbox field 
        private void DisplayTasks()
        {
            ListBox.Items.Clear();
            for (int x = 0; x < nextEmptySpot; x++)
            {
                ListBox.Items.Add(Astronomical_Processing[x]);
            }
        }
        #region AddEditDelete

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                if (ListBox.Items.Count < max)
                {
                    //Integer data input by user will be assigned to the next spot in the 
                    //array and displayed in the listbox field when the add button is selected
                    try
                    {
                        Astronomical_Processing[nextEmptySpot] = int.Parse(TextBox.Text);
                        nextEmptySpot++;
                        DisplayTasks();
                        TextBox.Clear();
                        ToolStripStatus.Text = "The data has been added.";
                    }
                    catch
                    //Where data input is not integer type, the user will be prompted to input
                    //the correct data type when the add button is selected
                    {
                        MessageBox.Show("Please input a whole number.");
                        ToolStripStatus.Text = "";

                    }
                }
                else
                //When the add button is used and the maximum number of items in the array 
                //has been filled, the user will be notified
                {
                    MessageBox.Show("The maximum number of items has been reached.");
                    ToolStripStatus.Text = "";
                }

            }
            else
            //Where the add button has been selected and no data input into the text box
            //the user will be prompted to input an integer
            {
                MessageBox.Show("The text box is empty. Please input a whole number.");
                ToolStripStatus.Text = "";
            }
        }

        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            //Where the user has not selected an item in the array to edit, a message will 
            //appear prompting the user to select an item
            if (ListBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select the item you wish to edit in the listbox.");
            }
            //Data input by the user will replace the item selected in the array (displayed in the 
            //listbox) when the edit button is selected
            else if (!string.IsNullOrEmpty(TextBox.Text))
            {
                string currentItem = ListBox.SelectedItem.ToString();
                int taskIndex = ListBox.FindString(currentItem);
                Astronomical_Processing[taskIndex] = int.Parse(TextBox.Text);
                ToolStripStatus.Text = "The item has been edited.";
            }
            //When no replacement data is included in the text box and an item in the array is
            //selected, when the edit button is selected, the user will be prompted to include the
            //replacement data in the text box
            else
            {
                MessageBox.Show("Please select an item from the list to edit and include the replacement input in the text box.");
                ToolStripStatus.Text = "";
            }
            DisplayTasks();
            TextBox.Clear();

        }
        //Item selected by the user in the array (displayed in the listbox) will be deleted when the
        //delete button is selected
        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            if (ListBox.SelectedIndex != -1)
            {
                string currentItem = ListBox.SelectedItem.ToString();
                int taskIndex = ListBox.FindString(currentItem);
                DialogResult DeleteTask = MessageBox.Show("Are you sure you want to delete this data?", "Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (DeleteTask == DialogResult.Yes)
                {
                    Astronomical_Processing[taskIndex] = Astronomical_Processing[nextEmptySpot - 1];
                    nextEmptySpot--;
                    ToolStripStatus.Text = "The item has been deleted.";
                    DisplayTasks();
                    TextBox.Clear();
                }
                //When the user selects 'No' a message box will appear to confirm the item has
                //not been deleted
                else
                {
                    MessageBox.Show("The item has NOT been deleted.");
                    ToolStripStatus.Text = "";
                }
                //When the user selects the delete button without selecting an item to be deleted,
                //a message box will appear, prompting them to select an item
            }
            else
            {
                MessageBox.Show("Please select an item from the list to delete.");
                ToolStripStatus.Text = "";
            }

        }
        #endregion

        #region Sort

        //Bubble sort
        private void ButtonSort_Click(object sender, EventArgs e)
        {
            //Declaring integer I as 0 - this is the index value in the array that the sort will commence from
            //When I is less than the length of the array, I will increases by 1
            for (int i = 0; i < nextEmptySpot; i++)
            {
                //Declaring integer J as I + 1
                //When J is less than the length of the array, J will increase by 1 
                for (int j = i + 1; j < nextEmptySpot; j++)
                {
                    //If I is greater than J
                    if (Astronomical_Processing[i] > Astronomical_Processing[j])
                    {
                        //Declaring integer 'temp' to be the same value as array index I
                        int temp = Astronomical_Processing[i];
                        //Setting the value of array index J to array index I
                        Astronomical_Processing[i] = Astronomical_Processing[j];
                        //Stting the value of array index J to original value of array index I
                        Astronomical_Processing[j] = temp;
                    }
                }
            }
            DisplayTasks();
            ToolStripStatus.Text = "The data has been sorted.";
        }
        #endregion

        #region Search
        private void ButtonSearch_Click(object sender, EventArgs e)

        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                int target = int.Parse(TextBox.Text);
                int min = 0;
                int max = nextEmptySpot - 1;
                int mid = 0;
                bool found = false;

                while (min <= max)
                {
                    //Declaring the middle point of the array
                    mid = (min + max) / 2;
                    //If the target is found at the middle point, the loop ends 
                    if (target == Astronomical_Processing[mid])
                    {
                        found = true;
                        break;
                        //If the target is not found at the first mid point, the program will 
                        //determine if the target is higher or lower than the oriignal mid point and define
                        //a new mid point based on this result. This process will continue until either the
                        //target is located or the whole array has been searched and the target not found
                    }
                    else if (target < Astronomical_Processing[mid])
                    {
                        max = mid - 1;
                    }
                    else
                    {
                        min = mid + 1;
                    }

                }
                //If the target is located, the program will display a message to confirm 
                //and highlight the result in the listbox
                if (found)
                {
                    ToolStripStatus.Text = "Item found at element [" + mid + "]";
                    TextBox.Clear();
                    ListBox.SetSelected(mid, true);
                }
                //If the target is not found, the program will display a message to confirm this and
                //prompt the user to ensure that the data is sorted. The search result will not be 
                //if the data is not first sorted
                else
                {
                    MessageBox.Show("Item not found. " +
                        "For accurate results, please ensure that the data is sorted.");
                    ToolStripStatus.Text = "";
                    TextBox.Clear();
                }
            }
            else
            {
                MessageBox.Show("Please enter a whole number to search. ");
                ToolStripStatus.Text = "";
                TextBox.Clear();
            }

        }
        #endregion

        #region Utilities
        //The 'test' button assigns 24 random numbers to the array and displays them in the
        //listbox
        private void ButtonTest_Click(object sender, EventArgs e)
        {
            Random randNum = new Random();
            nextEmptySpot = 0;

            for (int i = 0; i < 24; i++)
            {
                Astronomical_Processing[nextEmptySpot] = randNum.Next(10, 100);
                nextEmptySpot++;
            }
            DisplayTasks();
            ToolStripStatus.Text = "Random test data displayed.";
        }
        #endregion

    }

}

