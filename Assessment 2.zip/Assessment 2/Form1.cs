﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        static int max = 24;
        string[] Astronomical_Processing = new string[max];
        int nextEmptySpot = 0;

        private void DisplayTasks()
        {
            ListBox.Items.Clear();
            for (int x = 0; x < nextEmptySpot; x++)
            {
                ListBox.Items.Add(Astronomical_Processing[x]);
            }
        }

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                Astronomical_Processing[nextEmptySpot] = TextBox.Text;
                nextEmptySpot++;
                DisplayTasks();
                TextBox.Clear();
            }
            else
                ToolStripStatus.Text = "Cannot Add: Text box is empty";
        }

        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBox.Text))
            {
                string currentItem = ListBox.SelectedItem.ToString();
                int taskIndex = ListBox.FindString(currentItem);
                Astronomical_Processing[taskIndex] = TextBox.Text;
            }
            else
            {
                ToolStripStatus.Text = "Cannot Edit: Please select an item from the list";
            }
            DisplayTasks();
            TextBox.Clear();
        }       

        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            if (ListBox.SelectedIndex != -1)
            {
                string currentItem = ListBox.SelectedItem.ToString();
                int taskIndex = ListBox.FindString(currentItem);
                DialogResult DeleteTask = MessageBox.Show("Are you sure you want to Delete this task?", "Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (DeleteTask == DialogResult.Yes)
                {
                    Astronomical_Processing[taskIndex] = Astronomical_Processing[nextEmptySpot - 1];
                    nextEmptySpot--;
                    ToolStripStatus.Text = "Task has been Deleted";
                    DisplayTasks();
                    TextBox.Clear();
                }
                else
                    ToolStripStatus.Text = "Task NOT Deleted";
            }
            else
                ToolStripStatus.Text = "Cannot Delete: Please select a task from the list";
        }
        
    }
}
